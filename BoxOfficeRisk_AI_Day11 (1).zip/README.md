# BoxOfficeRisk AI
### Movie Box Office Success Classification and Revenue Prediction

## Overview

BoxOfficeRisk AI is a machine learning project designed to investigate
historical movie box office performance.

It combines two predictive systems:

1. Movie success classification.
2. Box office revenue regression.

It also includes exploratory analysis, SQL analytics, feature engineering,
model comparison, feature importance and interactive predictions.

## Problem Statement

Film production involves financial uncertainty. A movie's budget, genre,
release timing, runtime and production characteristics may be associated
with its historical box office performance.

This project investigates those relationships and develops machine
learning models using historical movie metadata.

## Dataset

TMDB Box Office Dataset:
https://huggingface.co/datasets/Jesscoyle111/TMDB-box-office

The dataset contains movie metadata including budget, revenue, genres,
runtime, release date, production companies, cast and director.

Dataset license: CC-BY-NC-SA 4.0 as indicated by the dataset card.
Review its terms before reuse or redistribution.

The project uses the Hugging Face datasets library to load the data
directly into Google Colab.

## Project Objectives

- Analyse historical box office performance.
- Identify genre-level revenue patterns.
- Explore budget and revenue relationships.
- Perform SQL-based movie industry analysis.
- Build a movie success classification model.
- Build a revenue prediction model.
- Compare multiple machine learning algorithms.
- Interpret model feature importance.
- Provide an interactive prediction function.

## Machine Learning Tasks

### 1. Classification

Three outcome classes are defined using the gross
revenue-to-budget multiple:

- Flop: below 1x
- Break-even / Moderate: 1x to below 2x
- Hit: 2x or higher

These are project-defined analytical categories, not official
industry classifications.

### 2. Regression

Predicts log-transformed worldwide box office revenue and converts
the prediction back into the dataset's revenue units.

## Feature Engineering

Features include:

- Log-transformed budget
- Runtime
- Release month
- Release year
- Cast count
- Production company count
- Primary genre
- Original language
- Director category

Revenue, popularity, ratings and vote counts are not used as
pre-release model inputs.

## Algorithms

Classification:
- Dummy Classifier
- Random Forest Classifier
- Extra Trees Classifier

Regression:
- Random Forest Regressor
- Extra Trees Regressor

## Evaluation Metrics

Classification:
- Accuracy
- Macro Precision
- Macro Recall
- Macro F1
- Weighted F1
- Confusion Matrix

Regression:
- Mean Absolute Error
- Root Mean Squared Error
- R-squared
- Root Mean Squared Logarithmic Error

Actual results are recorded in reports/evaluation_summary.json
and the model comparison CSV files.

## SQL Analysis

SQLite is used to investigate:

- Genre performance
- Yearly movie revenue patterns
- Budget and revenue by outcome category

## Visualizations

The outputs folder contains:

- Movie outcome distribution
- Budget distribution
- Revenue distribution
- Genre performance
- Budget versus revenue
- Correlation matrix
- Classification confusion matrix
- Revenue prediction comparison
- Classification feature importance
- Regression feature importance

## Repository Structure

```text
BoxOfficeRisk-AI/
|
|-- BoxOfficeRisk_AI_Day11.ipynb
|-- outputs/
|-- reports/
|-- models/
|-- data/
|-- requirements.txt
|-- README.md
|-- .gitignore
```

## How to Run

1. Open the notebook in Google Colab.
2. Run the complete implementation.
3. The dataset loads automatically through Hugging Face.
4. Review the analysis and model evaluation.
5. Test the interactive prediction function.

## Important Limitations

- Historical associations do not establish causation.
- Gross revenue divided by production budget is not net profit.
- Marketing, distribution, cinema shares, inflation and regional
  differences are not fully accounted for.
- Historical data may not represent today's film market.
- Random train/test splitting does not establish future-year
  forecasting performance.
- A director's identity and production characteristics may be
  associated with historical patterns that do not generalize.
- Model estimates should not be used as investment advice.
- Classification probabilities are model outputs, not guaranteed
  real-world probabilities.

## Future Improvements

- Temporal train/test validation.
- Inflation-adjusted revenue modelling.
- Indian cinema-specific analysis.
- Production budget and marketing cost modelling.
- SHAP-based explainability.
- Streamlit deployment.
- More robust data validation and monitoring.

## Author

Aditya Dhage

Data Science and AI Portfolio Project

## Disclaimer

This is an educational machine learning prototype, not a
production-grade financial forecasting system.

Movie data is associated with TMDB. This project is not endorsed
or certified by TMDB.